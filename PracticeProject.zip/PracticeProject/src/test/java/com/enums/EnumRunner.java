package com.enums;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

import org.assertj.core.util.Arrays;

public class EnumRunner {

	
	public static void main(String[] args) {
		
		//Java compiler by default adds a toString 
		
		//System.out.println(Severity.CRITICAL);
		
		System.out.println(Severity.CRITICAL.getFixinghours());
		
	}
}
