package com.enums;

public class SeverityClass {

	int fixinghours;
	
	
	
	public static final SeverityClass CRITICAL = new SeverityClass();
	public static final SeverityClass HIGH     = new SeverityClass();
	public static final SeverityClass MEDIUM     = new SeverityClass();
	public static final SeverityClass LOW     = new SeverityClass();

}
