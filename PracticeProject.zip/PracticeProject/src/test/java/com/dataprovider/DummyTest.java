package com.dataprovider;

import org.testng.annotations.Test;

public class DummyTest {
	
	@Test
	public void test3() {
		System.out.println("test3");
	}

}
